#pragma once

#ifdef _WIN32
#include "win-objects.h"
#else
#include "nix-objects.h"
#endif

