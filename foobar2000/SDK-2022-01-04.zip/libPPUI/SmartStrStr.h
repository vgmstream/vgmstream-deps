#pragma once

// Moved
#include <pfc/SmartStrStr.h>