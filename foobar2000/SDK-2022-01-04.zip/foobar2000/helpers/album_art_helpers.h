#pragma once
// stub, added for compatibility with fb2k mobile source