#pragma once

// fb2k mobile compat