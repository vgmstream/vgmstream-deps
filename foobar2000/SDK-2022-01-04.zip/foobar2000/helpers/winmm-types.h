#pragma once

// Blank header for source compatibility
// WAVEFORMATEX and such are declared here on non Windows