#pragma once

// All in win-objects.h & nix-objects.h
#include "platform-objects.h"