#pragma once

#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601
#include <SDKDDKVer.h>
#endif