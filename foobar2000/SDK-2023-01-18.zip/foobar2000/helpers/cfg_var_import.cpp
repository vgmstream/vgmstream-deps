#include "StdAfx.h"
#include "cfg_var_import.h"

// dummy C++ to get intellisense in cfg_var_import.h
