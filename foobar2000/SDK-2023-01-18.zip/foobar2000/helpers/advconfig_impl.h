#pragma once

// fb2k mobile compat
#include "../SDK/advconfig_impl.h"