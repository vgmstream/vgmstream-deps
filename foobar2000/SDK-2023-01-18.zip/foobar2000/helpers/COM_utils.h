#pragma once


#include <libPPUI/pp-COM-macros.h>

#define FB2K_COM_CATCH PP_COM_CATCH
