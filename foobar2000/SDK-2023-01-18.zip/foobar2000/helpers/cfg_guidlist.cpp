#include "StdAfx.h"
#include "cfg_guidlist.h"