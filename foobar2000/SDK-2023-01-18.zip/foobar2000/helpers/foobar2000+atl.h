#pragma once
#include "foobar2000-lite+atl.h"
#include <SDK/foobar2000-all.h>