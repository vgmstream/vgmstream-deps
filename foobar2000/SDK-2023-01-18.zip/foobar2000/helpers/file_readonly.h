#pragma once
// fb2k mobile compat

#include "../SDK/filesystem_helper.h"