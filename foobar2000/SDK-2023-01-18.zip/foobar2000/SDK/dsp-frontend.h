#pragma once
#include "keyValueIO.h"

typedef fb2k::keyValueIO dsp_preset_edit_callback_v3;

namespace fb2k {
    static const double dsp_slider_lag = 0.2;
}
