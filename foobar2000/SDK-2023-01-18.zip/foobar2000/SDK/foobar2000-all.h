#pragma once
// Redirect to foobar2000.h
#include "foobar2000.h"
