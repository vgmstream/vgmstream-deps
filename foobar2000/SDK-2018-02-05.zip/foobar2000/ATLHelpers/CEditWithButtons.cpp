#include "stdafx.h"
#include "CEditWithButtons.h"
// All in the header - CPP present to make MS intellisense stop showing nonsensical errors